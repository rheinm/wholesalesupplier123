<?php
/**
 * @package TelkomXsight
 */

namespace Xsight\SMSOTP;

use Xsight\Base\Submenu;
use Xsight\Interfaces\Feature;
use Xsight\Base\Setting;
use Xsight\Callbacks\FieldCallback;
use Xsight\Callbacks\SanitizeCallback;

class Admin implements Feature{

	private $sub_menu;
	private $field_callback;
	private $sanitize_callback;
		
	public function __construct()
	{
		$this->sub_menu = new Submenu('Login with SMSOTP API Integration', 'SMS OTP', 'edit_dashboard','telkom_xsight_smsotp_setting', [$this, 'settingPage']);
		$this->field_callback = new FieldCallback();
		$this->sanitize_callback = new SanitizeCallback();
	}

	public function addParent($parent_menu)
	{
		$this->sub_menu->addParentMenu($parent_menu);
	}

	public function register_pages()
	{
		$this->sub_menu->add();
	}

	public function register_settings()
	{
		$this->buildSettingPage();
	}

	public function register_shortcodes()
	{
		add_shortcode('xsight_otp_validation', [$this, 'generateXsightOTPValidationForm']);
	}

	public function register_filters()
	{
 		add_action( 'woocommerce_register_post', [$this, 'validatePhoneNumberForOTP'], 10, 3 );
 		add_action( 'woocommerce_created_customer', [$this, 'insertXsightOTPValidatedMetaKey'] );
 		add_action( 'woocommerce_registration_redirect', [$this,'redirectToValidatePhoneNumberUsingOTP']);
 		add_action( 'wp', [$this, 'checkIfXsightOTPValidated'] );
	}

	public function insertXsightOTPValidatedMetaKey($user_id)
	{
		update_user_meta($user_id,'xsight_otp_validated', false);
		$credential = $this->getCredential();
	}

	public function redirectToValidatePhoneNumberUsingOTP( ) {
		$user_id = get_current_user_id();
		$credential = $this->getCredential();
		$phoneNum = get_user_meta($user_id, 'user_phone', true);
		$digit = get_option('xsight_smsotp_digit');
		$args = [
			'headers' => [
				'Accept' => 'application/json',
				'Content-type' => 'application/x-www-form-urlencoded',
				'Authorization' => $credential->token_type.' '.$credential->access_token
			],
			'body' => [
				'phoneNum' => $phoneNum,
				'digit' => $digit
			],
			'method' => 'PUT'
		];

		$response = wp_remote_request('https://api.mainapi.net/smsotp/1.0.1/otp/xsight-otp', $args);
		wp_safe_redirect(home_url().'/validate-phone-number');
	}

	public function generateXsightOTPValidationForm()
	{
		$html = '
			<form method="POST">
				<p>
					Input the OTP that has been sent to your phone<br/>
					<input type="text" name="xsight_otp_code">
				</p>
				<p>
					<input type="submit" name="xsight_otp_validate" value="Validate">
				</p>
				<p>
					<input type="submit" name="xsight_resend_otp_code" value="Resend OTP Code">
				</p>
			</form>
		';

		if(isset($_POST['xsight_otp_validate']))
		{
			$xsight_otp_code = sanitize_text_field($_POST['xsight_otp_code']);
			if(preg_match('/[0-9]{2,10}/', $xsight_otp_code))
			{
				$credential = $this->getCredential();
				if(isset($credential->error))
				{
					$html.="<p>$credential->error_description</p>";
				}
				else
				{
					$args = [
						'headers' => [
							'Accept' => 'application/json',
							'Content-type' => 'application/x-www-form-urlencoded',
							'Authorization' => $credential->token_type.' '.$credential->access_token
						],
						'body' => [
							'otpstr' => $xsight_otp_code,
							'digit' => get_option('xsight_smsotp_digit')
						]
					];

					$response = wp_remote_post('https://api.mainapi.net/smsotp/1.0.1/otp/xsight-otp/verifications', $args);
					$response_code = wp_remote_retrieve_response_code($response);
					if($response_code == 200)
					{
						$user_id = get_current_user_id();
						update_user_meta($user_id,'xsight_otp_validated', true);
						$html .= "<p>Your phone number has been validated</p>";
					}
					else{
						$html .= "<p>Your OTP is invalid or maybe your OTP has been expired.</p>";
					}
				}
			}
		}
		else if(isset($_POST['xsight_resend_otp_code']))
		{
			$user_id = get_current_user_id();
			$credential = $this->getCredential();
			$phoneNum = get_user_meta($user_id, 'user_phone', true);
			$digit = get_option('xsight_smsotp_digit');
			$args = [
				'headers' => [
					'Accept' => 'application/json',
					'Content-type' => 'application/x-www-form-urlencoded',
					'Authorization' => $credential->token_type.' '.$credential->access_token
				],
				'body' => [
					'phoneNum' => $phoneNum,
					'digit' => $digit
				],
				'method' => 'PUT'
			];

			wp_remote_request('https://api.mainapi.net/smsotp/1.0.1/otp/xsight-otp', $args);
		}
		return $html;
	}

	public function getCredential()
	{
		$xsight_credential = get_option('xsight_credential');

		if(!$xsight_credential || ($xsight_credential && $xsight_credential->expires_in < time()))
		{
			$ba = "Basic ".base64_encode(get_option('xsight_client_id').':'.get_option('xsight_client_secret'));
			$args = [
				'headers' 	=> 'Authorization: ' . $ba,
				'timeout'	=> 5,
				'body'		=> [
					'grant_type'	=> 'client_credentials'
				]
			];
			$response = wp_remote_post('https://api.mainapi.net/token',$args);
			$response_code = wp_remote_retrieve_response_code($response);
			$body = json_decode(wp_remote_retrieve_body($response));
			
			if($response_code == 200)
			{
				$body->expires_in = time() + $body->expires_in;
				update_option('xsight_credential',$body);
			}
			else
			{
				update_option('xsight_credential',false);	
			}
			$xsight_credential = $body;	
			
		}
		return $xsight_credential;
	}

	public function checkIfXsightOTPValidated()
	{
		//ubah code agar validasi dilakukan kalau user bukan admin
		global $wp;
		$user_id = get_current_user_id();
		$request = substr($wp->request, strrpos($wp->request, '/'));
		$whitelist = ['validate-phone-number','/customer-logout','my-account'];
		$user = wp_get_current_user();
		$allowed_roles = ['administrator'];
		if( !array_intersect($allowed_roles, $user->roles ) && $user_id !== 0 && !in_array($request,$whitelist))
		{
			$otp_validated = get_user_meta($user_id, 'xsight_otp_validated', true);
			if(!$otp_validated) wp_safe_redirect(home_url().'/validate-phone-number');
		}
	}

	public function validatePhoneNumberForOTP( $username, $email, $validation_errors )
	{
		if(!isset($_POST['reg_phone']) || empty($_POST['reg_phone']))
		{
			$validation_errors->add('user_phone_error','Phone number must be filled');
		}
		else
		{
			if(!preg_match('/^[0-9]{11,16}$/', $_POST['reg_phone'] ))
				$validation_errors->add('user_phone_error','Phone number must be number and between 11 until 16 digits');
		}
		return $validation_errors;
	}

	public function settingPage()
	{
		require_once plugin_dir_path(__FILE__)."../../views/admin/smsotp/setting.php";
	}

	public function buildSettingPage()
	{
		$this->sanitize_callback->setting = 'xsight_smsotp_setting';
		$setting = new Setting();
		$setting->createOptionGroup('xsight_smsotp_setting')
				->intoSection(
					'xsight_smsotp_section',
					'Insert the total digit of the OTP')
				->intoPage($this->sub_menu)
				->addField(
					'xsight_smsotp_digit',
					'Total Digit',
					[$this->field_callback, 'textField'],
					[$this->sanitize_callback, 'smsotp_sanitize_setting'])
				->generate_for_wp();
	}

}