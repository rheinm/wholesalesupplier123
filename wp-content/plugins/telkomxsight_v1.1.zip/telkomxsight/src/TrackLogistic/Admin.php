<?php
/**
 * @package TelkomXsight
 */

namespace Xsight\TrackLogistic;

use Xsight\Interfaces\Feature;

class Admin implements Feature {

	public function __construct()
	{

	}

	public function addParent($parent_menu)
	{
		return;
	}

	public function register_pages()
	{
		return;
	}

	public function register_settings()
	{
		return;
	}

	public function register_filters()
	{
		return;
	}

	public function register_shortcodes()
	{
		add_shortcode('xsight_track_logistic',[$this, 'generateTrackLogisticPage']);
	}

	public function generateTrackLogisticPage()
	{
		$html = 
		'<form action="" method="GET">
		<p>
			Start Date <br/>
			<input type="date" name="xsight_track_start_date">
		</p>
		<p>
			End Date <br/>
			<input type="date" name="xsight_track_end_date">
		</p>
		<p>
			<input type="submit" name="xsight_logistic_schedule" value="Check Logistic Schedule">
		</p>
		</form>
		<form action="" method="GET">
		<p>
			Container No. <br/>
			<input type="text" name="xsight_track_container_no">
		</p>
		<p>
			<input type="submit" name="xsight_track_container" value="Track Container">
		</p>
		</form>';

		if(isset($_GET['xsight_logistic_schedule']))
		{
			$start_date = sanitize_text_field($_GET['xsight_track_start_date']);
			$end_date = sanitize_textarea_field($_GET['xsight_track_end_date']);

			$credential = $this->getCredential();
			if(isset($credential->error))
			{
				$html.="<p>$credential->error_description</p>";
			}
			else
			{
				$args = [
					'headers' => [
						'Accept' => 'application/json',
						'Authorization' => $credential->token_type.' '.$credential->access_token
					]
				];

				$response = wp_remote_get('https://api.mainapi.net/logistic/v1.0/vessel/schedule?start='.$start_date.'&end='.$end_date,$args);
				$response_code = wp_remote_retrieve_response_code($response);
				if($response_code == 200)
				{
					$html.='
					<div style="overflow:auto">
					<table border="1">
						<thead>
							<tr>
								<th>Vessel Name</th>
								<th>Vessel Reference</th>
								<th>Shipping Agent</th>
								<th>ETA</th>
								<th>ETD</th>
								<th>Voyage In</th>
								<th>Voyage Out</th>
								<th>Origin Port</th>
								<th>Final Port</th>
								<th>Last Port</th>
								<th>Next Port</th>
								<th>Status</th>
							</tr>
						</thead>
						<tbody>
					';
					$body = json_decode(wp_remote_retrieve_body($response));
					foreach ($body->payload as $val) {
						$html .= '
						<tr>
							<td>'.$val->vessel_name.'</td>
							<td>'.$val->vessel_reference.'</td>
							<td>'.$val->shipping_agent.'</td>
							<td>'.$val->eta.'</td>
							<td>'.$val->etd.'</td>
							<td>'.$val->voyage_in.'</td>
							<td>'.$val->voyage_out.'</td>
							<td>'.$val->origin_port.'</td>
							<td>'.$val->final_port.'</td>
							<td>'.$val->last_port.'</td>
							<td>'.$val->next_port.'</td>
							<td>'.$val->status.'</td>
						</tr>';
					}
					$html.='
						</tbody>
					</table>
					</div>';
				}
				else
				{
					$html.="<p>Failed to retrieve vessel schedule</p>";
				}
			}
		}
		else if(isset($_GET['xsight_track_container']))
		{
			$container_no = sanitize_text_field($_GET['xsight_track_container_no']);
			$credential = $this->getCredential();
			if(isset($credential->error))
			{
				$html.="<p>$credential->error_description</p>";
			}
			else
			{
				$args = [
					'headers' => [
						'Accept' => 'application/json',
						'Authorization' => $credential->token_type.' '.$credential->access_token
					],
					'timeout'	=> 5,
					'body' => [
						'no_cont'	=> $container_no,
					]
				];

				$response = wp_remote_get('https://api.mainapi.net/logistic/v1.0/container/track',$args);
				$response_code = wp_remote_retrieve_response_code($response);
				if($response_code == 200)
				{
					$html.='
					<div style="overflow:auto">
					<table border="1">
						<thead>
							<tr>
								<th>Container No</th>
								<th>Vessel</th>
								<th>Shipping Line</th>
								<th>Voyage</th>
								<th>ATA</th>
								<th>ATD</th>
								<th>Consignee</th>
								<th>Export/Import</th>
								<th>Full/Empty</th>
								<th>Weight</th>
								<th>Seal ID</th>
								<th>POL</th>
								<th>POD</th>
								<th>Bay Position</th>
								<th>Record Time</th>
								<th>ISO Code</th>
								<th>Size Type</th>
								<th>GIO Time</th>
								<th>DL Time</th>
								<th>Stack</th>
								<th>ETA</th>
								<th>ETD</th>
								<th>Yard</th>
								<th>Last Activity</th>
								<th>Doc Info</th>
								<th>Weight Terminal</th>
								<th>Weight Shipper</th>
								<th>Voyage In</th>
							</tr>
						</thead>
						<tbody>
					';
					$body = json_decode(wp_remote_retrieve_body($response));
					foreach ($body->payload as $val) {
						$html .= 'val
						<tr>
							<td>'.$val->cotainer_no.'</td>
							<td>'.$val->vessel.'</td>
							<td>'.$val->shipping_line.'</td>
							<td>'.$val->voyage.'</td>
							<td>'.$val->ata.'</td>
							<td>'.$val->atd.'</td>
							<td>'.$val->consignee.'</td>
							<td>'.$val->ex_im.'</td>
							<td>'.$val->full_empty.'</td>
							<td>'.$val->weight.'</td>
							<td>'.$val->seal_id.'</td>
							<td>'.$val->pol.'</td>
							<td>'.$val->pod.'</td>
							<td>'.$val->bay_position.'</td>
							<td>'.$val->record_time.'</td>
							<td>'.$val->iso_code.'</td>
							<td>'.$val->size_type.'</td>
							<td>'.$val->gio_time.'</td>
							<td>'.$val->dl_time.'</td>
							<td>'.$val->stack.'</td>
							<td>'.$val->eta.'</td>
							<td>'.$val->etd.'</td>
							<td>'.$val->yard.'</td>
							<td>'.$val->last_activity.'</td>
							<td>'.$val->doc_info.'</td>
							<td>'.$val->weight_terminal.'</td>
							<td>'.$val->weight_shipper.'</td>
							<td>'.$val->voyage_in.'</td>
						</tr>';
					}
					$html.='
						</tbody>
					</table>
					</div>';
				}
				else if($response_code == 404)
				{
					$html.="<p>Container not found</p>";	
				}
				else
				{
					$html.="<p>Failed to retrieve container data</p>";
				}
			}
		}
		return $html;
	}

	public function getCredential()
	{
		$xsight_credential = get_option('xsight_credential');

		if(!$xsight_credential || ($xsight_credential && $xsight_credential->expires_in < time()))
		{
			$ba = "Basic ".base64_encode(get_option('xsight_client_id').':'.get_option('xsight_client_secret'));
			$args = [
				'headers' 	=> 'Authorization: ' . $ba,
				'timeout'	=> 5,
				'body'		=> [
					'grant_type'	=> 'client_credentials'
				]
			];
			$response = wp_remote_post('https://api.mainapi.net/token',$args);
			$response_code = wp_remote_retrieve_response_code($response);
			$body = json_decode(wp_remote_retrieve_body($response));
			
			if($response_code == 200)
			{
				$body->expires_in = time() + $body->expires_in;
				update_option('xsight_credential',$body);
			}
			else
			{
				update_option('xsight_credential',false);	
			}
			$xsight_credential = $body;	
			
		}
		return $xsight_credential;
	}
}