<?php
/**
 * @package TelkomXsight
 */

namespace Xsight\SMSNotification;
use Xsight\Base\Submenu;
use Xsight\Callbacks\FieldCallback;
use Xsight\Callbacks\SanitizeCallback;
use Xsight\Interfaces\Feature;
use Xsight\Base\Setting;

class Admin implements Feature{
	
	private $sub_menu;

	public function __construct()
	{
	}

	public function addParent($parent_menu)
	{
		return;
	}

	public function register_pages()
	{
		return;
	}

	public function register_settings()
	{
		return;
	}

	public function register_shortcodes()
	{
		add_shortcode('xsight_sms_promotion_form',[$this, 'generateSendPromotionForm']);
	}

	public function generateSendPromotionForm()
	{
		$html = 
		'<form action="" method="POST">
		<p>
			Phone No (required) <br/>
			<input type="text" name="xsight_phone_no">
		</p>
		<p>
			Message (required) <br/>
			<textarea cols="35" rows="5" name="xsight_message"></textarea>
		</p>
		<p>
			<input type="submit" name="xsight_send_message" value="Send Message">
		</p>
		</form>';

		if(isset($_POST['xsight_send_message']))
		{
			$phone_no = sanitize_text_field($_POST['xsight_phone_no']);
			$message = sanitize_textarea_field($_POST['xsight_message']);
			$credential = $this->getCredential();
			$args = [
				'headers' => [
					'Accept' => 'application/json',
					'Content-type' => 'application/x-www-form-urlencoded',
					'Authorization' => $credential->token_type.' '.$credential->access_token
				],
				'timeout'	=> 5,
				'body' => [
					'msisdn'	=> $phone_no,
					'content'	=> $message
				]
			];

			$response = wp_remote_post('https://api.mainapi.net/smsnotification/1.0.0/messages',$args);
			$response_code = wp_remote_retrieve_response_code($response);
			if($response_code == 200)
			{
				$html.="<p>Message sent</p>";
			}
			else
			{
				$html.="<p>Failed to sent message</p>";
			}
		}
		return $html;
	}

	public function getCredential()
	{
		$xsight_credential = get_option('xsight_credential');
		if(!$xsight_credential || ($xsight_credential && $xsight_credential->expires_in < time()))
		{
			$ba = "Basic ".base64_encode(get_option('xsight_client_id').':'.get_option('xsight_client_secret'));
			$args = [
				'headers' 	=> 'Authorization: ' . $ba,
				'timeout'	=> 5,
				'body'		=> [
					'grant_type'	=> 'client_credentials'
				],
				'method'	=> 'POST'
			];

			$response = wp_remote_request('https://api.mainapi.net/token',$args);
			$body = json_decode(wp_remote_retrieve_body($response));
			$body->expires_in = time() + $body->expires_in;
			update_option('xsight_credential',$body);
		}
		return $xsight_credential;
	}

}