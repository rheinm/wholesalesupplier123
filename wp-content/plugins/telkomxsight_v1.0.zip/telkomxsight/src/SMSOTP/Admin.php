<?php
/**
 * @package TelkomXsight
 */

namespace Xsight\SMSOTP;

use Xsight\Base\Submenu;
use Xsight\Interfaces\Feature;
use Xsight\Base\Setting;
use Xsight\Callbacks\FieldCallback;
use Xsight\Callbacks\SanitizeCallback;

class Admin implements Feature{

	private $sub_menu;
	private $field_callback;
	private $sanitize_callback;
		
	public function __construct()
	{
		$this->sub_menu = new Submenu('Login with SMSOTP API Integration', 'SMS OTP', 'edit_dashboard','telkom_xsight_smsotp_setting', [$this, 'settingPage']);
		$this->field_callback = new FieldCallback();
		$this->sanitize_callback = new SanitizeCallback();
	}

	public function addParent($parent_menu)
	{
		$this->sub_menu->addParentMenu($parent_menu);
	}

	public function register_pages()
	{
		$this->sub_menu->add();
	}

	public function register_settings()
	{
		$this->buildSettingPage();
	}

	public function register_shortcodes()
	{
		return;
	}

	public function settingPage()
	{
		require_once plugin_dir_path(__FILE__)."../../views/admin/smsotp/setting.php";
	}

	public function buildSettingPage()
	{
		$this->sanitize_callback->setting = 'xsight_smsotp_setting';
		$setting = new Setting();
		$setting->createOptionGroup('xsight_smsotp_setting')
				->intoSection(
					'xsight_smsotp_section',
					'Insert the total digit of the OTP')
				->intoPage($this->sub_menu)
				->addField(
					'xsight_smsotp_digit',
					'Total Digit',
					[$this->field_callback, 'textField'],
					[$this->sanitize_callback, 'smsotp_sanitize_setting'])
				->generate_for_wp();
	}

}