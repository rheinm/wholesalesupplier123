<?php
/**
 * The template for displaying the footer
 *
 * Contains footer content and the closing of the #main and #page div elements.
 *
 */
?>

			<?php get_template_part('footer/footer-home', ''); ?>
			<?php get_template_part('footer/footer-area', ''); ?>
    </div><!-- end wrapper -->
    <!-- END SITE -->
  	<?php wp_footer(); ?>
</body>
</html>